package laboratorio;

public abstract class Parseable {
    public abstract void setStringField(String key, String value);
    public abstract void setIntField(String key, int value);
    public abstract void setBooleanField(String key, boolean value);
    public abstract void setFloatField(String key, float value);
}
